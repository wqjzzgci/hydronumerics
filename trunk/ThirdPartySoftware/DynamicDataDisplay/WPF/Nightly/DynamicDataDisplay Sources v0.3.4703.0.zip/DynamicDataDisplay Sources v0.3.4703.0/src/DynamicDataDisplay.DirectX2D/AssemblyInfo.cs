﻿using System.Windows.Markup;
using Microsoft.Research.DynamicDataDisplay;

[assembly: XmlnsDefinition(D3AssemblyConstants.DefaultXmlNamespace, "Microsoft.Research.DynamicDataDisplay.DirectX2D")]
