﻿MultipleDataPlotting

This is a sample application for DynamicDataDisplay charting library.

This application contains a window with adjustable number of ChartPlotters (5x5 by default), 
each plotter displays animated sine data.

FPS (on Intel 945G, Intel T7200 @ 2000 MHz, Windows 7 Beta):
	25 plotters:
		no axes - 25
		axes	- 2
	1 plotter & 25 charts on it:
		no axes	- 17
		axes	- 8
	