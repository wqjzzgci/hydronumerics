﻿namespace DynamicDataDisplay.Markers.ForestDisplay
{
	public static class TreeViews
	{
		public const string Ellipse = "ellipse";
		public const string Rectangle = "rect";
		public const string RoundTriangle = "roundTriangle";
		public const string Triangle = "triangle";
	}
}