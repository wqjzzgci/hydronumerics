﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Research.DynamicDataDisplay.Charts.Markers;

namespace DynamicDataDisplay.Markers
{
	public class CandleStickChart : DevMarkerChart
	{

	}
}
